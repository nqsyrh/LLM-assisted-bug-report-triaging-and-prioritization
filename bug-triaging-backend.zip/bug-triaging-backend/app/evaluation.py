"""
evaluation.py
Same comparison as evaluation_ml_baseline.py (LLM zero-shot vs Naive Bayes
vs SVM vs Random Forest, 5-fold CV on TF-IDF features), but returns
structured metrics instead of printing, and stores them so the
Evaluation tab doesn't need to retrain on every page load.

Run with: python -m app.evaluation
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
import json

from .database import SessionLocal, Base, engine
from . import models

LABEL_ORDER = ["Critical", "High", "Medium", "Low"]


def _macro_metrics(y_true, y_pred):
    """Returns (accuracy, macro_precision, macro_recall, macro_f1, per_class_dict)."""
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=LABEL_ORDER, zero_division=0
    )
    per_class = {
        label: {
            "precision": round(float(precision[i]), 3),
            "recall": round(float(recall[i]), 3),
            "f1": round(float(f1[i]), 3),
            "support": int(support[i]),
        }
        for i, label in enumerate(LABEL_ORDER)
    }
    macro_precision = round(float(precision.mean()), 3)
    macro_recall = round(float(recall.mean()), 3)
    macro_f1 = round(float(f1.mean()), 3)
    return round(accuracy, 3), macro_precision, macro_recall, macro_f1, per_class


def run_full_evaluation():
    """
    Reproduces evaluation_ml_baseline.py end-to-end against the EvalExample
    table (loaded from llm_predictions_v2.csv), and writes results into
    ModelEvalResult so /evaluation can serve them instantly afterward.
    """
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        examples = db.query(models.EvalExample).all()
        if not examples:
            print("No evaluation examples found — run seed_data first.")
            return

        texts = [e.clean_text for e in examples]
        y_true = [e.mapped_severity for e in examples]

        # Same TF-IDF setup as evaluation_ml_baseline.py
        vectorizer = TfidfVectorizer(max_features=500, stop_words="english")
        X = vectorizer.fit_transform(texts)

        cv = KFold(n_splits=5, shuffle=True, random_state=42)

        results = {}

        nb_preds = cross_val_predict(MultinomialNB(), X, y_true, cv=cv)
        results["Naive Bayes"] = _macro_metrics(y_true, nb_preds)

        svm_preds = cross_val_predict(
            SVC(class_weight="balanced", kernel="linear"), X, y_true, cv=cv
        )
        results["SVM"] = _macro_metrics(y_true, svm_preds)

        rf_preds = cross_val_predict(
            RandomForestClassifier(class_weight="balanced", n_estimators=100, random_state=42),
            X, y_true, cv=cv
        )
        results["Random Forest"] = _macro_metrics(y_true, rf_preds)

        # LLM (Zero-Shot) — use the ALREADY-COMPUTED predicted_severity from
        # llm_predictions_v2.csv, exactly as evaluation_ml_baseline.py does
        # (it reads llm_predictions_v2.csv rather than re-running bart-large-mnli).
        llm_preds = [e.predicted_severity for e in examples]
        results["LLM (Zero-Shot)"] = _macro_metrics(y_true, llm_preds)

        # Persist
        db.query(models.ModelEvalResult).delete()
        for model_name, (acc, prec, rec, f1, per_class) in results.items():
            row = models.ModelEvalResult(
                model_name=model_name,
                accuracy=acc,
                macro_precision=prec,
                macro_recall=rec,
                macro_f1=f1,
                per_class_report=json.dumps(per_class),
            )
            db.add(row)
        db.commit()

        print("Evaluation complete:")
        for model_name, (acc, prec, rec, f1, _) in sorted(results.items(), key=lambda x: x[1][0], reverse=True):
            print(f"  {model_name:25s} acc={acc:.1%}  P={prec:.3f}  R={rec:.3f}  F1={f1:.3f}")

    finally:
        db.close()


if __name__ == "__main__":
    run_full_evaluation()
