"""
main.py
FastAPI application — REST layer over the bug triaging system.

Run with: uvicorn app.main:app --reload --port 8000
Interactive docs (works like Postman in the browser): http://localhost:8000/docs
"""
import json
from typing import Optional, List

from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func

from . import models, schemas, classifier, duplicates
from .database import engine, get_db, Base

# Creates tables if they don't exist yet (safe no-op if seed_data already ran)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="LLM-Assisted Bug Report Triaging API",
    description="REST API for automatic bug classification, duplicate detection, "
                 "and priority prediction — FORM 01A objectives 1-5.",
    version="1.0.0",
)

# Allows the Streamlit dashboard (running on a different port) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {
        "message": "Bug Triaging API is running",
        "docs": "/docs",
        "endpoints": ["/reports", "/duplicates", "/evaluation", "/stats"],
    }


# ============================================================
# Reports
# ============================================================

@app.post("/reports", response_model=schemas.ClassifyResponse)
def create_report(report: schemas.BugReportCreate, db: Session = Depends(get_db)):
    """
    Submit a NEW bug report for live classification:
    severity (bart-large-mnli), duplicate check (FAISS + MiniLM against
    existing corpus), and priority score — same logic as your batch scripts.
    """
    # Assign an ID if the client didn't supply one
    new_id = report.id
    if new_id is None:
        max_id = db.query(func.max(models.BugReport.id)).scalar() or 0
        new_id = max_id + 1
    elif db.query(models.BugReport).filter(models.BugReport.id == new_id).first():
        raise HTTPException(status_code=409, detail=f"Report with id {new_id} already exists.")

    # 1. Severity classification (facebook/bart-large-mnli)
    severity, confidence = classifier.classify_severity(report.full_text)

    # 2. Duplicate check against existing corpus (all-MiniLM-L6-v2 + FAISS)
    is_dup, matched_id, similarity = duplicates.find_duplicate_for_text(report.full_text, db)

    # 3. Priority score (same formula as priority_scoring.py)
    priority_score = classifier.calculate_priority(severity, is_dup)

    # Persist the new report
    new_report = models.BugReport(
        id=new_id,
        repo=report.repo,
        full_text=report.full_text,
        predicted_severity=severity,
        model_confidence=confidence,
        is_duplicate=is_dup,
        priority_score=priority_score,
    )
    db.add(new_report)

    # If flagged as a duplicate, also record the pair (consistent with duplicate_pairs.csv structure)
    if is_dup and matched_id is not None:
        matched_report = db.query(models.BugReport).filter(models.BugReport.id == matched_id).first()
        pair = models.DuplicatePair(
            report_1_id=matched_id,
            report_1_text=(matched_report.full_text[:100] if matched_report else ""),
            report_2_id=new_id,
            report_2_text=report.full_text[:100],
            similarity_score=similarity,
        )
        db.add(pair)

    db.commit()

    return schemas.ClassifyResponse(
        id=new_id,
        predicted_severity=severity,
        model_confidence=confidence,
        is_duplicate=is_dup,
        matched_duplicate_id=matched_id,
        similarity_score=similarity,
        priority_score=priority_score,
    )


@app.get("/reports", response_model=List[schemas.BugReportOut])
def list_reports(
    severity: Optional[List[str]] = Query(None, description="Filter by severity, e.g. Critical, High"),
    min_priority: Optional[float] = Query(None),
    max_priority: Optional[float] = Query(None),
    duplicates_only: bool = Query(False),
    repo: Optional[str] = Query(None),
    search: Optional[str] = Query(None, description="Keyword or bug ID search"),
    limit: int = Query(100, le=1000),
    offset: int = Query(0),
    db: Session = Depends(get_db),
):
    """
    List bug reports with the same filters as your dashboard sidebar:
    severity, priority score range, duplicates only, repository, keyword/ID search.
    """
    q = db.query(models.BugReport)

    if severity:
        q = q.filter(models.BugReport.predicted_severity.in_(severity))
    if min_priority is not None:
        q = q.filter(models.BugReport.priority_score >= min_priority)
    if max_priority is not None:
        q = q.filter(models.BugReport.priority_score <= max_priority)
    if duplicates_only:
        q = q.filter(models.BugReport.is_duplicate == True)  # noqa: E712
    if repo:
        q = q.filter(models.BugReport.repo == repo)
    if search:
        if search.isdigit():
            q = q.filter(models.BugReport.id == int(search))
        else:
            q = q.filter(models.BugReport.full_text.ilike(f"%{search}%"))

    q = q.order_by(models.BugReport.priority_score.desc())
    return q.offset(offset).limit(limit).all()


@app.get("/reports/{report_id}", response_model=schemas.BugReportOut)
def get_report(report_id: int, db: Session = Depends(get_db)):
    report = db.query(models.BugReport).filter(models.BugReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


# ============================================================
# Duplicates
# ============================================================

@app.get("/duplicates", response_model=List[schemas.DuplicatePairOut])
def list_duplicates(
    min_similarity: float = Query(0.0, ge=0.0, le=1.0),
    limit: int = Query(100, le=1000),
    db: Session = Depends(get_db),
):
    """All duplicate pairs detected via semantic similarity — matches your Duplicates tab."""
    q = db.query(models.DuplicatePair).filter(
        models.DuplicatePair.similarity_score >= min_similarity
    ).order_by(models.DuplicatePair.similarity_score.desc())
    return q.limit(limit).all()


@app.get("/duplicates/{pair_id}/compare", response_model=schemas.DuplicateCompareOut)
def compare_duplicate_pair(pair_id: int, db: Session = Depends(get_db)):
    """
    Full side-by-side comparison for one duplicate pair — matches your
    dashboard's expandable 'Reference comparison' rows, but with full
    report details instead of truncated 100-char previews.
    """
    pair = db.query(models.DuplicatePair).filter(models.DuplicatePair.id == pair_id).first()
    if not pair:
        raise HTTPException(status_code=404, detail="Duplicate pair not found")

    report_1 = db.query(models.BugReport).filter(models.BugReport.id == pair.report_1_id).first()
    report_2 = db.query(models.BugReport).filter(models.BugReport.id == pair.report_2_id).first()
    if not report_1 or not report_2:
        raise HTTPException(status_code=404, detail="One or both reports in this pair no longer exist")

    return schemas.DuplicateCompareOut(
        report_1=report_1,
        report_2=report_2,
        similarity_score=pair.similarity_score,
    )


# ============================================================
# Evaluation
# ============================================================

@app.get("/evaluation", response_model=List[schemas.ModelEvalOut])
def get_evaluation(db: Session = Depends(get_db)):
    """
    Accuracy / precision / recall / F1 for LLM (Zero-Shot) vs Naive Bayes
    vs SVM vs Random Forest — matches your Evaluation tab's Model
    Performance Comparison. Precomputed by `python -m app.evaluation`.
    """
    results = db.query(models.ModelEvalResult).all()
    if not results:
        raise HTTPException(
            status_code=404,
            detail="No evaluation results yet — run `python -m app.evaluation` first."
        )
    return results


@app.get("/evaluation/{model_name}/detail")
def get_evaluation_detail(model_name: str, db: Session = Depends(get_db)):
    """Per-class (Critical/High/Medium/Low) precision/recall/F1/support for one model."""
    result = db.query(models.ModelEvalResult).filter(
        models.ModelEvalResult.model_name == model_name
    ).first()
    if not result:
        raise HTTPException(status_code=404, detail=f"No evaluation result for '{model_name}'")
    return {
        "model_name": result.model_name,
        "accuracy": result.accuracy,
        "per_class": json.loads(result.per_class_report),
    }


# ============================================================
# Stats (dashboard summary cards)
# ============================================================

@app.get("/stats", response_model=schemas.StatsOut)
def get_stats(db: Session = Depends(get_db)):
    """The four summary numbers shown at the top of your dashboard."""
    total = db.query(models.BugReport).count()
    critical = db.query(models.BugReport).filter(models.BugReport.predicted_severity == "Critical").count()
    dup_pairs = db.query(models.DuplicatePair).count()

    breakdown = {}
    for sev in ["Critical", "High", "Medium", "Low"]:
        breakdown[sev] = db.query(models.BugReport).filter(models.BugReport.predicted_severity == sev).count()

    return schemas.StatsOut(
        total_reports=total,
        critical_count=critical,
        duplicates_found=dup_pairs,
        currently_showing=total,
        severity_breakdown=breakdown,
    )
